package com.nabil.microservicesV2.curencyexchangeservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurencyExchangeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurencyExchangeServiceApplication.class, args);
	}

}
